from django.apps import AppConfig


class JslDjangoSitemapConfig(AppConfig):
    name = 'jsl_django_sitemap'
